import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class TheLostEssences extends PApplet {

static final int WIDTH = 1280;
static final int HEIGHT = 704;
int videoScale = 32;
int rows, cols;

Map terrainMap;
Player p;


// Setup call
public void setup() {
  size(WIDTH, HEIGHT);


  cols = WIDTH/videoScale;
  rows = HEIGHT/videoScale;

  Tiles loadedTiles = new Tiles();
  terrainMap = new Map(loadedTiles, "simple.map");
  p = new Player(loadedTiles);
}

// Draw loop
public void draw() {
  //println(frameRate);
  background(30, 140, 30);
  terrainMap.drawMap();
  p.drawPlayer();
}

public void keyPressed() {
  if (key == 'a') {
    p.movePlayer(0);
  }
  if (key == 'w') {
    p.movePlayer(1);
  } 
  if (key == 'd') {
    p.movePlayer(2);
  } 
  if (key == 's') {
    p.movePlayer(3);
  }
}

public void mouseClicked() {
  //p.teleportPlayer(mouseX, mouseY);
  p.shoot(mouseX, mouseY);
}

class Map {
  //int mapWidth;
  //int mapHeight;

  // Tile variables
  PImage grass, stone, water;

  // Loaded tiles
  Tiles tiles;

  // Map
  int[][] map;

  public Map(Tiles tiles, String mapName) {
    BufferedReader reader = createReader("maps/" + mapName);
    this.tiles = tiles;
    map = new int[rows][cols];

    String line;
    String[] split;
    int rowCounter = 0;
    try {
      while ( (line = reader.readLine ()) != null) {
        split = split(line, ',');
        for (int i=0; i<split.length; i++) {
          map[rowCounter][i] = Integer.parseInt(split[i]);
        }
        rowCounter += 1;
      }
    } 
    catch (IOException e) {
    } 
    finally {
      try {
        reader.close();
      } 
      catch (IOException e) {
      }
    }
  }

  public void drawMap() {
    // Begin loop for columns
    for (int i = 0; i < cols; i++) {
      // Begin loop for rows
      for (int j = 0; j < rows; j++) {
        // Scaling up to draw a rectangle at (x,y)
        int x = i*videoScale;
        int y = j*videoScale;
       
        // For every column and row, a rectangle is drawn at an (x,y) location scaled and sized by videoScale.
        image(tiles.get(map[j][i]), x, y);
      }
    }
  }
}

class NPC {
  boolean friendly;
  final int D_LEFT = 0;
  final int D_UP = 1;
  final int D_RIGHT = 2;
  final int D_DOWN = 3;
  int posX, posY;

  String name;
  int level;
  int hp;
  int dmg;

  int direction_image;
}

class Player {
  final int D_LEFT = 0;
  final int D_UP = 1;
  final int D_RIGHT = 2;
  final int D_DOWN = 3;
  public int posX, posY;

  String name;
  int level;
  int charClass;
  int race;
  int xp;
  int hp;
  int dmg;

  int direction_image;

  Tiles tiles;

  public Player(Tiles tiles) {
    this.tiles = tiles;
    this.posX = 5;
    this.posY = 5;
    direction_image = 0;
  }

  public void drawPlayer() {
    //rect((posX * 32) +2, (posY * 32) +2, 28, 28);
    if (direction_image == 0) {
      image(tiles.warrior_l, (posX * 32), (posY * 32));
    } else if (direction_image == 1) {
      image(tiles.warrior_r, (posX * 32), (posY * 32));
    }
  }

  public void movePlayer(int direction) {
    switch (direction) {
    case D_UP:    
      posY -= 1;
      break;
    case D_DOWN:  
      posY += 1;
      break;
    case D_LEFT:  
      posX -= 1;
      direction_image = 0;
      break;
    case D_RIGHT:  
      posX += 1;
      direction_image = 1;
      break;
    }
  }

  public void teleportPlayer(int x, int y) {
    posX = x / 32;
    posY = y/ 32;
  }

  public void shoot(int x, int y) {
    line(posX*32, posY*32, x, y);
  }
}

class Tiles {
  PImage stone;
  PImage water;
  PImage water_t_l;
  PImage water_t;
  PImage water_t_r;
  PImage water_r;
  PImage water_b_r;
  PImage water_b;
  PImage water_b_l;
  PImage water_l;
  PImage water_c_b_l;
  PImage water_c_b_r;
  PImage water_c_t_l;
  PImage water_c_t_r;
  PImage grass;
  PImage sword;
  public PImage warrior_l;
  public PImage warrior_r;

  private PImage[] tiles;

  public Tiles() {
    stone = loadImage("stone.png");
    grass = loadImage("grass.png");
    sword = loadImage("sword.png");
    warrior_l = loadImage("warrior_l.png");
    warrior_r = loadImage("warrior_r.png");

    water = loadImage("water.png");
    water_t_l = loadImage("sand_water_top_left.png");
    water_t = loadImage("water_sand_top.png");
    water_t_r = loadImage("sand_water_top_right.png");
    water_r = loadImage("water_sand_right.png");
    water_b_r = loadImage("water_sand_bottom_right.png");
    water_b = loadImage("water_sand_bottom.png");
    water_b_l = loadImage("water_sand_bottom_left.png");
    water_l = loadImage("water_sand_left.png");
    water_c_b_l = loadImage("water_c_b_l.png");
    water_c_b_r = loadImage("water_c_b_r.png");
    water_c_t_l = loadImage("water_c_t_l.png");
    water_c_t_r = loadImage("water_c_t_r.png");

    tiles = new PImage[20];

    tiles[1] = stone;
    tiles[0] = grass;
    tiles[2] = water;
    tiles[3] = water_t_l;
    tiles[4] = water_t;
    tiles[5] = water_t_r;
    tiles[6] = water_r;
    tiles[7] = water_b_r;
    tiles[8] = water_b;
    tiles[9] = water_b_l;
    tiles[10] = water_l;
    tiles[11] = water_c_b_l;
    tiles[12] = water_c_b_r;
    tiles[13] = water_c_t_l;
    tiles[14] = water_c_t_r;
  }

  public PImage get(int i) {
    return tiles[i];
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "TheLostEssences" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
